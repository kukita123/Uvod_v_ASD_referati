﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sorts
{
    class Program
    {
        static void FillingArray(int[] array)
        {
            Random rnd = new Random();
            for (int i = 0; i < array.Length; i++)
            {
                array[i] = rnd.Next(0, 20);
            }
        }
        static void DisplaingArray(int[] array)
        {
            for (int i = 0; i < array.Length; i++)
            {
                Console.WriteLine("Arr[{0}] = {1}", i, array[i]);
            }           
        }
        static void BubbleSort(int[] arr)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                for (int j = 0; j < arr.Length - 1; j++)
                {
                    if (arr[j] > arr[j + 1])
                    {
                        int temp = arr[j];
                        arr[j] = arr[j + 1];
                        arr[j + 1] = temp;
                    }
                }
            }
        }
        static void CountingSort(int[] arr)
        {
            int[] output = new int[arr.Length];

            int max = arr[0];
            for (int i = 1; i < arr.Length; i++)
            {
                if (max < arr[i])
                {
                    max = arr[i];
                }
            }
            int[] count = new int[max + 1];

            for (int i = 0; i < arr.Length; i++)
            {
                count[arr[i]]++;
            }

            for (int i = 1; i <= max; i++)
            {
                count[i] += count[i - 1];
            }

            for (int i = arr.Length - 1; i >= 0; i--)
            {
                output[count[arr[i]] - 1] = arr[i];
                count[arr[i]]--;
            }

            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = output[i];
            }
        }
        static void Main(string[] args)
        {
            Random rnd = new Random();
            int[] array1 = new int[rnd.Next(5, 10)];
            int[] array2 = new int[rnd.Next(5, 10)];

            FillingArray(array1);
            FillingArray(array2);

            DisplaingArray(array1);
            Console.WriteLine("----------");
            DisplaingArray(array2);

            Console.WriteLine("***********");
            BubbleSort(array1);
            CountingSort(array2);

            DisplaingArray(array1);
            Console.WriteLine("----------");
            DisplaingArray(array2);

            Console.ReadKey();
        }
    }
}
