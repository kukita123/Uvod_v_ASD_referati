﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.RegularExpressions;

namespace FinalWork_SortingGame
{
    class Program
    {
        //------------------------------------------------- Working with files --------------------------------------------//
        public static List<string> fileLines()
        {
            string filePath = @"C:\Users\Atanas\source\repos\FinalWork-SortingGame\FinalWork-SortingGame\Top10.txt";
            List<string> lines = new List<string>();
            lines = File.ReadAllLines(filePath).ToList();
            return lines;
        }
        public static void WriteNewScore(List<string> newest)
        {
            string filePath = @"C:\Users\Atanas\source\repos\FinalWork-SortingGame\FinalWork-SortingGame\Top10.txt";
            File.WriteAllLines(filePath, newest);
        }
        public static int checkNewScore(List<string> file, int score)
        {
            int n = 0;
            int newScorePosition = -1;
            foreach (string line in file)
            {
                string[] tokens = line.Split(' ');
                int points = int.Parse(tokens[0]);
                    if (score > points)
                    {
                        newScorePosition = n; break;
                    }
            }
            return newScorePosition;
        }
        //------------------------------------------------------ Converting Methods -----------------------------------------------//
        static int[] ConvertToArray(int A)
        {
            int[] array = new int[6];
            for (int i = 0; i < array.Length; i++)
            {
                array[i] = A % 10;
                A /= 10;
            }
            return array;
        }
        static int ConvertToInt(int[] arr)
        {
            int num = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                num *= 10;
                num += arr[i];
            }
            return num;
        }
        //---------------------------------------------------------- Sorting Algoritms ---------------------------------------------//
        //
        //------------------------------------------------------ Merge Sort Algoritm (MSA) --------------------------------------------------//
        public static int[] mergeSort(int[] array)
        {
            int[] left;
            int[] right;
            int[] result = new int[array.Length];
            if (array.Length <= 1)
                return array; //avoid an infinite recursion

            int midPoint = array.Length / 2;//The middle of the array
            left = new int[midPoint]; //left half of the array

            if (array.Length % 2 == 0) //if array is even it will have the same amount of elements in each side
                right = new int[midPoint];
            else
                right = new int[midPoint + 1]; //This case is when the array length isn't even
            for (int i = 0; i < midPoint; i++)
                left[i] = array[i]; //fill left half
            int x = 0; //index counter
            for (int i = midPoint; i < array.Length; i++)//fill right half
            {
                right[x] = array[i];//start from the middle because the left half is already filled
                x++;
            }
            left = mergeSort(left);
            right = mergeSort(right);
            result = merge(left, right);
            return result;
        }

        public static int[] merge(int[] left, int[] right)
        {
            int resultLength = right.Length + left.Length;
            int[] result = new int[resultLength];
            //
            int indexLeft = 0, indexRight = 0, indexResult = 0;
            //while either array still has an element
            while (indexLeft < left.Length || indexRight < right.Length)
            {
                //if both arrays have elements  
                if (indexLeft < left.Length && indexRight < right.Length)
                {
                    //If item on left array is less than item on right array, add that item to the result array 
                    if (left[indexLeft] <= right[indexRight])
                    {
                        result[indexResult] = left[indexLeft];
                        indexLeft++;
                        indexResult++;
                    }
                    // else the item in the right array wll be added to the results array
                    else
                    {
                        result[indexResult] = right[indexRight];
                        indexRight++;
                        indexResult++;
                    }
                }
                //if only the left array still has elements, add all its items to the results array
                else if (indexLeft < left.Length)
                {
                    result[indexResult] = left[indexLeft];
                    indexLeft++;
                    indexResult++;
                }
                //if only the right array still has elements, add all its items to the results array
                else if (indexRight < right.Length)
                {
                    result[indexResult] = right[indexRight];
                    indexRight++;
                    indexResult++;
                }
            }
            return result;
        }
        //
        //------------------------------------ BubbleSort algoritm ---------------------------------------------------------//
        static void BubbleSortUp(int[] array)
        {

            for (int i = 0; i < array.Length; i++)
            {
                for (int j = 0; j < array.Length - 1; j++)
                {
                    if(array[j]  > array[j + 1])
                    {
                        int temporary = array[j];
                        array[j] = array[j + 1];
                        array[j + 1] = temporary;
                    }
                }
            }

        }
        //
        //-------------------------------------------- Reversed number using QuickBubbleSort -------------------------------------------//
        static void QuickBubbleSort(int[] arr)
        {
            bool flag = true;
            while (flag)
            {
                flag = false;
                for (int i = 0; i < arr.Length - 1; i++)
                {
                    if (arr[i] < arr[i + 1])
                    {
                        int temporary = arr[i];
                        arr[i] = arr[i + 1];
                        arr[i + 1] = temporary;
                        flag = true;
                    }
                }
            }
        }
        //
        static int[] SplitDoConnect(int[] arr, int moves)
        {
            int middle = arr.Length / 2;
            int[] arr1 = new int[middle];
            int[] arr2 = new int[arr.Length - middle];
            int indexer = 0;
            for (int i = 0; i < arr1.Length; i++)
            {
                arr1[i] = arr[i];
            }
            for (int i = middle; i < arr.Length; i++)
            {
                arr2[indexer] = arr[i];
                indexer++;
            }
            if(moves == 2)
            {
                BubbleSortUp(arr1);
                QuickBubbleSort(arr2);
            }
            if(moves == 1)
            {
                BubbleSortUp(arr2);
                QuickBubbleSort(arr1);
            }
            for (int i = 0; i < arr1.Length; i++)
            {
                arr[i] = arr1[i];
            }
            int indexer2 = 0;
            for (int i = middle; i < arr.Length; i++)
            {
                arr[i] = arr2[indexer2];
                indexer2++;
            }
            return arr;
        }
        //--------------------------------------------------------------- Using Sorting ---------------------------------------------------------//
        static int Sorting(int A, int moves) //This method applies different sortings, depending on that on which move you are.
        {
            int result = 0;
            int[] array = ConvertToArray(A); 
            array = mergeSort(array); // First it is Sorted
            if (moves == 3) //Here is used MergeSort and than it is reversed
            {
                Array.Reverse(array);
            }
            if (moves == 2 || moves == 1)
            {
                array = SplitDoConnect(array, moves); //Here First Time it is made the first half of it is from lower to upper the second half is from upper to lower
            }                                         //Secnond time the first half is from upper to lower and the second half is sorted from lower to upper
            result = ConvertToInt(array);
            return result;
        }
        //
        //--------------------------------------------------------- Checker for bulls and cows -------------------------------------------------//
        //
        public static int[] CheckBullsCows(int A, int B)
        {
            int[] result = new int[2];
            int bullsAt = 0;
            int cowsAt = 0;
            int[] compnum = new int[6];
            int[] plynum = new int[6];
            compnum = ConvertToArray(A);
            plynum = ConvertToArray(B);
            for (int i = 0; i < compnum.Length; i++)
            {
                for (int j = 0; j < plynum.Length; j++)
                {
                    if(compnum[i] == plynum[j])
                    {
                        if(i == j)
                        {
                            bullsAt++;
                        }
                        else
                        {
                            cowsAt++;
                        }
                    }
                }
            }
            if(cowsAt != bullsAt)
            {
                if(bullsAt > cowsAt)
                {
                    cowsAt = cowsAt - bullsAt;
                }
                if (cowsAt < 0)
                {
                    cowsAt *= -1;
                }
            }
            result[0] = cowsAt;
            result[1] = bullsAt;
            return result;
        }
        //
        //------------------------------------------------ Generating Randowm Computer Number (GRCN) -----------------------------------------//
        static int GenRandNum()
        {
            Random rand = new Random();
            int num = rand.Next(100000, 999999);
            return num;
        }
        static bool RepeatingNums(int num)
        {
            bool flag = false;
            if (flag == false)
            {
                int[] array = new int[6];
                for (int i = 0; i < array.Length; i++)
                {
                    array[i] = num % 10;
                    num /= 10;
                }
                for (int i = 0; i < array.Length - 1; i++)
                {
                    for (int j = i + 1; j < array.Length; j++)
                    {
                        if (array[i] == array[j])
                        {
                            return flag = false;
                        }
                        else
                        {
                            flag = true;
                        }
                    }
                }
            }
            return flag;
        }
        static int Display()
        {
            int num = GenRandNum();
            while (RepeatingNums(num) == false)
            {
                num = GenRandNum();
            }
            return num;
        }
        //
        static void ToD0(List<string> result, int points, string lineToAdd)
        {
            int index = checkNewScore(result, points);
            if (index < 0)
                result.Add(lineToAdd);
            else
                result.Insert(index, lineToAdd);
        }
        //
        //-----
        //
        //-------------------------------------------------- From here is the Main method ----------------------------------------------------//
        //
        static void Main(string[] args)
        {
            Console.WriteLine("Hello there. THis is my final work. It is a sorting game. You have to gues a number which is sorted every move. " +
                "You will have 4 moves." +
                " Only at the first move the computer number won't be sorted. " +
                " Computer generates 6 digit number (without repeating numbers in it). YOu have to guess it. Every move the number is sorted," +
                " so the place of the digits" +
                " could be changed. Finaly you will se how much points you have (1 right guess = 1 point). Hope you enjoy it.");
            Console.WriteLine();
            List<string> result = new List<string>(10);
            int points = 0;
            int guess;
            int moves = 4;
            int CN = Display();
            Console.WriteLine(CN);
            while (moves >= 0) //Repeating this thing until you have no more moves
            {
                Console.WriteLine("Please enter your guess.");
                guess = int.Parse(Console.ReadLine());
                while(RepeatingNums(guess) == false)
                {
                    Console.WriteLine("Well the randomly generated computer number doesn't have repeating, so your musn't have too. Please Enter number without repeating digits.");
                    guess = int.Parse(Console.ReadLine());
                }
                if(moves == 4)//first time it does not do anything
                {
                    Console.WriteLine("You have " + CheckBullsCows(CN, guess)[1] + " bulls and " + CheckBullsCows(CN, guess)[0] + " cows.");
                    points += ((CheckBullsCows(CN, guess)[1] * 2) + CheckBullsCows(CN, guess)[0]);
                }
                if(moves < 4 && moves >= 1) //Every next move changes the computer number by sorting it
                {
                    CN = Sorting(CN, moves);
                    Console.WriteLine("You have " + CheckBullsCows(CN, guess)[1] + " bulls and " + CheckBullsCows(CN, guess)[0] + " cows.");
                    points += ((CheckBullsCows(CN, guess)[1] * 2) + CheckBullsCows(CN, guess)[0]);
                }
                if(moves == 0)//When you don't have any moves left, it will show you your points.
                {
                    Console.WriteLine("The game is over and your points are: " + points);
                    Console.WriteLine("Please write your name.");
                    string name = Console.ReadLine();
                    string addLine = points + " points; Player: " + name;
                    result = fileLines();
                    if(result.Count == 0)
                    {
                        result.Add(addLine);
                    }
                    if (result.Count < 10 && result.Count > 0)
                    {
                        ToD0(result, points, addLine);
                    }
                    if(result.Count > 10)
                    {
                        ToD0(result, points, addLine);
                    }
                    WriteNewScore(result);
                }
                moves--;
            }
            Console.ReadKey();
        }
    }
}
