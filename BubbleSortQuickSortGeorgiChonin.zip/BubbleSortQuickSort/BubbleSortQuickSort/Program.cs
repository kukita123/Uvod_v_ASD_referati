﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BubbleSortQuickSort
{
    class Program
    {
        static void BubbleSort1(int[] array)
        {
            for (int i = 0; i < array.Length; i++)
            {
                for (int j = 0; j < array.Length - 1; j++)
                {
                    if (array[j] > array[j + 1]) // swap the elements
                    {
                        int temp = array[j];
                        array[j] = array[j + 1];
                        array[j + 1] = temp;
                    } 
                }
            }
        }
        
        static void BubbleSortFlag(int[] array) //Faster
        {
            bool flag = true;
            while (flag)
            {
                flag = false;
                for (int i = 0; i < array.Length - 1; i++)
                {
                    if (array[i] > array[i + 1]) // swap the elements 
                    {
                        int temp = array[i];
                        array[i] = array[i + 1];
                        array[i + 1] = temp;
                        flag = true;
                    }
                }
            }
        }

        static private void QuickSort(int[] array, int start, int end)
        {
            if (start >= end)      
                return;
            int boundary = partition(array, start, end);
            QuickSort(array, start, boundary - 1);  //recursion occurs
            QuickSort(array, boundary + 1, end);
        }
        static void QuickSort(int[] array)  //only our target method is public
        {
            QuickSort(array, 0, array.Length - 1);
        }
        static int partition(int[] array, int start, int end)
        {
            int pivot = array[end];
            int boundary = start - 1;
            for (int i = start; i <= end; i++)
            {
                if (array[i] <= pivot)
                {
                    boundary++;
                    Swap(array, i, boundary);
                }
            }
            return boundary;
        }

        static void Swap(int[] array, int index1, int index2)
        {
            int temp = array[index1];
            array[index1] = array[index2];
            array[index2] = temp;
        }
        static void Print(int[] array)
        {
            foreach (var item in array)
            {
                Console.WriteLine(item);
            }
        }
        static void Main(string[] args)
        {
            int[] array = { 23, 14, 4, 9, 16, 3, 10 };
           
            Console.WriteLine("Quick sort");
            
            var watch = System.Diagnostics.Stopwatch.StartNew();

            QuickSort(array);
            
            watch.Stop();
           var elapsedMs = watch.ElapsedMilliseconds;
            
            Print(array);
            
            Console.WriteLine("Elapsed ms:"+elapsedMs);
            Console.WriteLine();
            Console.WriteLine("Bubble sort");
             watch = System.Diagnostics.Stopwatch.StartNew();
            BubbleSort1(array);
            watch.Stop();

             elapsedMs = watch.ElapsedMilliseconds;
            Print(array);

            Console.WriteLine("Elapsed ms:" + elapsedMs);

           
            Console.ReadKey(true);
            
        }
    }
}
